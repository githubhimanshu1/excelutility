var http=require('http');
var fs=require('fs');
var json2xls=require('json2xls');

var returnedobj='';
var ibibolink="http://developer.goibibo.com/api/cyclone/?app_id=fe10d8ec&app_key=161e84417ce4428a8a3598e2ff49d92b&city_id=1554245012668028405&check_in=20160929&check_out=20160930";
http.get(ibibolink,function(res){

	res.on('data', function (chunk) {
		
	returnedobj+=chunk;
    //console.log('BODY: ' + chunk);
  });
	res.on('end',function(){
		console.log("*****");
		//console.log(returnedobj);
		var obj=returnedobj;
		fs.writeFileSync("temp.json",obj);
		generatexls();

	});
	

}).on("error",function(){
	console.log("something went wrong");
}); 

function generatexls()
{
		
		var jsondat=require('./temp.json');
		var keyarray=Object.keys(jsondat.data);
		var masterarray=[];
		for(var i=0;i<keyarray.length;i++)
		{
			var obj={
						snapNo:keyarray[i],
						offerId:jsondat.data[keyarray[i]].offerids,
						pah:jsondat.data[keyarray[i]].pah,
						sf:jsondat.data[keyarray[i]].sf,
						ho:jsondat.data[keyarray[i]].ho,
						ibp:jsondat.data[keyarray[i]].ibp,
						fc:jsondat.data[keyarray[i]].fc,
						fwdp:jsondat.data[keyarray[i]].fwdp,
						rowid:jsondat.data[keyarray[i]].rowid,
						fcdt:jsondat.data[keyarray[i]].fcdt,
						egc:jsondat.data[keyarray[i]].egc,
						mp_wt:jsondat.data[keyarray[i]].mp_wt,
						op:jsondat.data[keyarray[i]].op,
						op_wt:jsondat.data[keyarray[i]].op_wt,
						fc_days:jsondat.data[keyarray[i]].fc_days,
						spf:jsondat.data[keyarray[i]].spf,
						mp:jsondat.data[keyarray[i]].mp

		};
		masterarray.push(obj);
		}
		var jsonobj=JSON.stringify(masterarray);
		
	
		
	var xls = json2xls(masterarray);

	var flname=Date.now()+'_data.xls'
	fs.writeFileSync(flname,xls,'binary');
	console.log("************************************************");
	console.log("Data dump is generated successfully. ->"+flname);
	console.log("************************************************");
}